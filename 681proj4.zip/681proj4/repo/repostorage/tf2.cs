﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
    public class test3
    {
        public bool testing()
        {

            Console.WriteLine("\n====== make instance of test3=======");
            return true;
        }
    }
}