﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
  public class test2
    {
        public bool testing()
        {
            Console.WriteLine("\n =======make instance of test2========");
            return false;
        }
    }
}