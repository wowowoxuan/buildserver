﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests
{
    class TestA
    {
       public static bool testing()
        {
            return true;
        }
    }
}
